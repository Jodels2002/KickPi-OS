#!/bin/bash
"/opt/retropie/emulators/amiberry/amiberry.sh"
