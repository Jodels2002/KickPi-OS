/* $VER: Start-ACTION.rexx 1.1 (28.11.2000) */

OPTIONS RESULTS
PARSE ARG files

/* Enter options for ACTION here */
/* Optionen f�r ACTION hier eintragen */
action_options="WINDOWPLAY AUTOPLAY"

oldstack=PRAGMA("STACK", 8192)

DO WHILE files~=="" 
    files=STRIP(files)
    IF files~=="" THEN DO
        IF left(files,1)='"' THEN DO
            PARSE VAR files '"'file'"' files
        END
        ELSE DO
            PARSE VAR files file" "files
        END

        IF EXISTS(file) THEN DO
            ADDRESS COMMAND 'ACTION >NIL: 'action_options' "'file'"'
        END
    END
END 

oldstack=PRAGMA("STACK",oldstack)
