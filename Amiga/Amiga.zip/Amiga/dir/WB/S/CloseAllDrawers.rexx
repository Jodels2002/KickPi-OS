/*
   $VER: CloseAllDrawers.rexx 1.0 (21.12.99)

  closes all drawers except root.
*/

options results

address WORKBENCH

GETATTR WINDOWS STEM WINDOW

do i = 0 to WINDOW.count-1
  IF WINDOW.i ~= "root" THEN
    WINDOW '"'||WINDOW.i||'"' CLOSE
END
